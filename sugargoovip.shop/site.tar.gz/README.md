# sugargoovip.shop

Production static website for SugargooVIP.

This archive contains the homepage, product catalog, buyer guides, SEO metadata, sitemap, robots.txt, favicon, responsive styles and scripts.
