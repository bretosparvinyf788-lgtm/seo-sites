
(() => {
  const MQ = window.matchMedia('(max-width:760px)');
  const labels = {
    en:['Show all 10 FAQs','Show fewer FAQs'],
    zh:['查看全部10条FAQ','收起FAQ'],
    es:['Ver las 10 preguntas','Mostrar menos'],
    fr:['Voir les 10 FAQ','Réduire les FAQ'],
    de:['Alle 10 FAQs anzeigen','Weniger FAQs'],
    pt:['Ver as 10 perguntas','Mostrar menos']
  };
  let expanded=false;
  function currentLang(){return (document.documentElement.lang||'en').toLowerCase().split('-')[0]}
  function setup(){
    const list=document.querySelector('.faq-list');
    if(!list || list.dataset.mobileCompactReady) return;
    list.dataset.mobileCompactReady='true';
    const items=[...list.querySelectorAll('details')];
    const button=document.createElement('button');
    button.type='button'; button.className='mobile-faq-toggle';
    button.setAttribute('aria-expanded','false');
    list.after(button);
    const render=()=>{
      const mobile=MQ.matches;
      items.forEach((item,index)=>{
        if(mobile){item.open=false; item.classList.toggle('mobile-faq-hidden',!expanded && index>=3)}
        else item.classList.remove('mobile-faq-hidden');
      });
      button.hidden=!mobile;
      const text=labels[currentLang()]||labels.en;
      button.textContent=expanded?text[1]:text[0];
      button.setAttribute('aria-expanded',String(expanded));
    };
    button.addEventListener('click',()=>{expanded=!expanded;render()});
    MQ.addEventListener?.('change',()=>{expanded=false;render()});
    document.addEventListener('sugargoovip:language',render);
    render();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',setup); else setup();
})();
