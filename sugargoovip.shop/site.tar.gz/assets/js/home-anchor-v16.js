(() => {
  const header = document.querySelector('.first-header');
  const navLinks = [...document.querySelectorAll('[data-home-nav]')];
  const sectionLinks = navLinks.filter(a => (a.getAttribute('href') || '').startsWith('#'));
  const targets = sectionLinks.map(a => document.querySelector(a.getAttribute('href'))).filter(Boolean);

  function headerOffset(){ return (header?.offsetHeight || 0) + 10; }
  function closeMobileNav(){ document.querySelector('.nav-row')?.classList.remove('nav-open'); }
  function setActive(id){
    sectionLinks.forEach(a => a.classList.toggle('is-active', a.getAttribute('href') === `#${id}`));
  }
  function goTo(hash, updateHistory = true){
    const target = document.querySelector(hash);
    if(!target) return;
    const top = target.getBoundingClientRect().top + window.scrollY - headerOffset();
    window.scrollTo({top: Math.max(0, top), behavior:'smooth'});
    if(updateHistory) history.replaceState(null, '', hash);
    setActive(target.id);
    closeMobileNav();
  }

  sectionLinks.forEach(a => a.addEventListener('click', e => {
    const hash = a.getAttribute('href');
    if(!hash || !document.querySelector(hash)) return;
    e.preventDefault();
    goTo(hash, true);
  }));

  if('IntersectionObserver' in window){
    const observer = new IntersectionObserver(entries => {
      const visible = entries.filter(e => e.isIntersecting).sort((a,b) => b.intersectionRatio - a.intersectionRatio)[0];
      if(visible) setActive(visible.target.id);
    }, {rootMargin:'-18% 0px -65% 0px', threshold:[0,.1,.25,.5]});
    targets.forEach(t => observer.observe(t));
  }

  window.addEventListener('hashchange', () => {
    if(location.hash && document.querySelector(location.hash)) goTo(location.hash, false);
  });
  window.addEventListener('load', () => {
    if(location.hash && document.querySelector(location.hash)) setTimeout(() => goTo(location.hash, false), 60);
    else setActive('home-top');
  });
})();