const products = window.PRODUCTS || [];
const STORAGE_KEY = 'sugargoovip-shortlist-v1';
let saved = new Set();
try { saved = new Set(JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')); } catch (_) { saved = new Set(); }

const categorySlug = value => String(value || '').toLowerCase();
const money = value => `$${Number(value).toFixed(2)}`;
const escapeHtml = value => String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));

function toast(message){
  const el = document.querySelector('[data-toast-v3]') || document.querySelector('.toast');
  if(!el) return;
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

function saveState(){
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify([...saved])); } catch (_) {}
  updateSavedUI();
}

function updateSavedUI(){
  document.querySelectorAll('[data-saved-count]').forEach(el => el.textContent = saved.size);
  document.querySelectorAll('[data-save-id]').forEach(btn => {
    const active = saved.has(btn.dataset.saveId);
    btn.classList.toggle('saved', active);
    btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    btn.textContent = active ? '♥' : '♡';
    btn.setAttribute('aria-label', active ? 'Remove from shortlist' : 'Save to shortlist');
  });
  renderShortlist();
}

function productCard(p){
  return `<article class="product-card-v3" data-category="${categorySlug(p.category)}">
    <div class="product-image-v3">
      <a href="${p.url}" target="_blank" rel="noopener" aria-label="Open ${escapeHtml(p.name)} in the live product catalog">
        <img src="${p.image}" alt="${escapeHtml(p.name)}" loading="lazy" decoding="async">
      </a>
      <span class="product-tag-v3">${escapeHtml(p.tag)}</span>
      <button class="save-product ${saved.has(p.id) ? 'saved' : ''}" type="button" data-save-id="${p.id}" aria-pressed="${saved.has(p.id)}" aria-label="${saved.has(p.id) ? 'Remove from shortlist' : 'Save to shortlist'}">${saved.has(p.id) ? '♥' : '♡'}</button>
    </div>
    <div class="product-content-v3">
      <span class="product-category-v3">${escapeHtml(p.category)} · Main-site product</span>
      <h3><a href="${p.url}" target="_blank" rel="noopener">${escapeHtml(p.name)}</a></h3>
      <div class="product-card-foot-v3">
        <span class="product-price-v3">${money(p.price)}</span>
        <a class="product-open-v3" href="${p.url}" target="_blank" rel="noopener">Open product ↗</a>
      </div>
    </div>
  </article>`;
}

function miniCard(p){
  return `<a class="finder-mini-card" href="${p.url}" target="_blank" rel="noopener">
    <img src="${p.image}" alt="${escapeHtml(p.name)}" loading="eager">
    <span class="finder-mini-copy"><b>${escapeHtml(p.name)}</b><span>${money(p.price)}</span></span>
  </a>`;
}

function initHeroFinder(){
  const input = document.querySelector('[data-hero-search]');
  const select = document.querySelector('[data-hero-category]');
  const results = document.querySelector('[data-hero-results]');
  const count = document.querySelector('[data-hero-result-count]');
  if(!results) return;
  const draw = () => {
    const term = (input?.value || '').toLowerCase().trim();
    const category = select?.value || 'all';
    const list = products.filter(p => (category === 'all' || categorySlug(p.category) === category) && `${p.name} ${p.category}`.toLowerCase().includes(term));
    count.textContent = list.length;
    results.innerHTML = list.length ? list.slice(0,3).map(miniCard).join('') : '<div class="shortlist-empty" style="grid-column:1/-1;padding:30px 10px"><b>No matches</b>Try another keyword.</div>';
  };
  input?.addEventListener('input', draw);
  select?.addEventListener('change', draw);
  draw();
}

function initProductExplorer(){
  const grid = document.querySelector('[data-product-grid-v3]');
  if(!grid) return;
  const input = document.querySelector('[data-grid-search]');
  const mobileCategory = document.querySelector('[data-mobile-category]');
  const sort = document.querySelector('[data-sort]');
  const count = document.querySelector('[data-grid-result-count]');
  let category = 'all';
  let term = '';

  const draw = () => {
    let list = products.filter(p => (category === 'all' || categorySlug(p.category) === category) && `${p.name} ${p.category}`.toLowerCase().includes(term));
    const mode = sort?.value || 'featured';
    list = [...list];
    if(mode === 'price-low') list.sort((a,b) => a.price - b.price);
    if(mode === 'price-high') list.sort((a,b) => b.price - a.price);
    if(mode === 'name') list.sort((a,b) => a.name.localeCompare(b.name));
    count.textContent = list.length;
    grid.innerHTML = list.length ? list.map(productCard).join('') : '<div class="shortlist-empty" style="grid-column:1/-1"><b>No matching finds</b>Try another product name or category.</div>';
    bindSaveButtons();
  };

  document.querySelectorAll('[data-filter-v3]').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('[data-filter-v3]').forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    category = btn.dataset.filterV3;
    if(mobileCategory) mobileCategory.value = category;
    draw();
  }));
  input?.addEventListener('input', () => { term = input.value.toLowerCase().trim(); draw(); });
  mobileCategory?.addEventListener('change', () => {
    category = mobileCategory.value;
    document.querySelectorAll('[data-filter-v3]').forEach(x => x.classList.toggle('active', x.dataset.filterV3 === category));
    draw();
  });
  sort?.addEventListener('change', draw);
  document.querySelectorAll('[data-jump-category]').forEach(btn => btn.addEventListener('click', () => {
    category = btn.dataset.jumpCategory;
    if(mobileCategory) mobileCategory.value = category;
    document.querySelectorAll('[data-filter-v3]').forEach(x => x.classList.toggle('active', x.dataset.filterV3 === category));
    draw();
    document.querySelector('#finds')?.scrollIntoView({behavior:'smooth'});
  }));
  draw();
}

function bindSaveButtons(){
  document.querySelectorAll('[data-save-id]').forEach(btn => {
    btn.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      const id = btn.dataset.saveId;
      if(saved.has(id)) { saved.delete(id); toast('Removed from shortlist'); }
      else { saved.add(id); toast('Saved to your shortlist'); }
      saveState();
    };
  });
}

function renderShortlist(){
  const container = document.querySelector('[data-shortlist-items]');
  if(!container) return;
  const list = products.filter(p => saved.has(p.id));
  container.innerHTML = list.length ? list.map(p => `<div class="shortlist-item">
    <a href="${p.url}" target="_blank" rel="noopener"><img src="${p.image}" alt="${escapeHtml(p.name)}"></a>
    <a href="${p.url}" target="_blank" rel="noopener"><b>${escapeHtml(p.name)}</b><span>${money(p.price)}</span></a>
    <button type="button" data-remove-id="${p.id}" aria-label="Remove ${escapeHtml(p.name)}">×</button>
  </div>`).join('') : '<div class="shortlist-empty"><b>Your shortlist is empty.</b>Tap the heart on any product card to save it here.</div>';
  container.querySelectorAll('[data-remove-id]').forEach(btn => btn.addEventListener('click', () => {
    saved.delete(btn.dataset.removeId);
    saveState();
    toast('Removed from shortlist');
  }));
}

function initShortlistDrawer(){
  const drawer = document.querySelector('[data-shortlist-drawer]');
  const overlay = document.querySelector('[data-shortlist-overlay]');
  const open = () => { drawer?.classList.add('open'); overlay?.classList.add('open'); drawer?.setAttribute('aria-hidden','false'); };
  const close = () => { drawer?.classList.remove('open'); overlay?.classList.remove('open'); drawer?.setAttribute('aria-hidden','true'); };
  document.querySelectorAll('[data-open-shortlist]').forEach(btn => btn.addEventListener('click', open));
  document.querySelector('[data-close-shortlist]')?.addEventListener('click', close);
  overlay?.addEventListener('click', close);
  document.querySelector('[data-clear-shortlist]')?.addEventListener('click', () => { saved.clear(); saveState(); toast('Shortlist cleared'); });
  document.addEventListener('keydown', event => { if(event.key === 'Escape') close(); });
}

function initMenu(){
  document.querySelector('.mobile-menu-v3')?.addEventListener('click', () => document.querySelector('.nav-v3')?.classList.toggle('open'));
  document.querySelector('.mobile-menu')?.addEventListener('click', () => document.querySelector('.nav')?.classList.toggle('open'));
}

function initLegacyProducts(){
  const grid = document.querySelector('[data-product-grid]');
  if(!grid) return;
  let active = 'all'; let term = '';
  const legacyCard = p => `<a class="product-card" href="${p.url}" target="_blank" rel="noopener" data-category="${categorySlug(p.category)}"><div class="product-image"><img src="${p.image}" alt="${escapeHtml(p.name)}" loading="lazy"><span class="badge">${escapeHtml(p.tag)}</span></div><div class="product-body"><h3>${escapeHtml(p.name)}</h3><div class="meta"><span>${escapeHtml(p.category)}</span><span>Main-site product</span></div><div class="price-row"><span class="price">${money(p.price)}</span><span class="product-link">View product ↗</span></div></div></a>`;
  const draw = () => { const list = products.filter(p => (active === 'all' || categorySlug(p.category) === active) && `${p.name} ${p.category}`.toLowerCase().includes(term)); grid.innerHTML = list.length ? list.map(legacyCard).join('') : '<div class="empty"><b>No matching products</b><br>Try another search or category.</div>'; };
  document.querySelectorAll('[data-filter]').forEach(btn => btn.addEventListener('click', () => { document.querySelectorAll('[data-filter]').forEach(x=>x.classList.remove('active')); btn.classList.add('active'); active=btn.dataset.filter; draw(); }));
  document.querySelectorAll('[data-search]').forEach(input => input.addEventListener('input', () => { term=input.value.toLowerCase().trim(); draw(); }));
  draw();
}

function initCalc(){
  const btn=document.querySelector('[data-calc]'); if(!btn) return;
  btn.addEventListener('click',()=>{const w=+document.querySelector('#weight').value||0;const l=+document.querySelector('#length').value||0;const d=+document.querySelector('#width').value||0;const h=+document.querySelector('#height').value||0;const charge=Math.max(w,(l*d*h)/6000);document.querySelector('[data-result]').textContent=charge.toFixed(2)+' kg';});
}

document.addEventListener('DOMContentLoaded', () => {
  initMenu(); initHeroFinder(); initProductExplorer(); initShortlistDrawer(); initLegacyProducts(); initCalc(); updateSavedUI();
});
