(() => {
  const send = (name, params = {}) => {
    if (typeof window.gtag === "function") window.gtag("event", name, params);
  };

  const labelFor = (element) =>
    (element.getAttribute("aria-label") || element.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 100);

  document.addEventListener("click", (event) => {
    const link = event.target.closest("a[href]");
    if (link) {
      let target;
      try {
        target = new URL(link.href, window.location.href);
      } catch (_) {
        target = null;
      }

      if (target && /(^|\.)kakobuymake\.com$/i.test(target.hostname)) {
        const product = link.closest("[data-product-id]");
        send("outbound_product_click", {
          destination_host: target.hostname,
          link_path: target.pathname,
          link_text: labelFor(link),
          source_page: window.location.pathname,
          product_id: product?.dataset.productId || "unknown",
          category: product?.dataset.category || "unknown",
          link_status: "destination_opened",
        });
      } else if (
        target &&
        target.origin === window.location.origin &&
        /^\/guides?(?:$|-)/.test(target.pathname)
      ) {
        send("guide_open", {
          link_path: target.pathname,
          link_text: labelFor(link),
        });
        send("guide_cta_click", {
          link_path: target.pathname,
          link_text: labelFor(link),
          source_page: window.location.pathname,
        });
      }
    }

    const saveButton = event.target.closest("[data-save], [data-save-id]");
    if (saveButton) {
      send("product_save_toggle", {
        product_id:
          saveButton.dataset.save || saveButton.dataset.saveId || "unknown",
      });
    }

    const categoryButton = event.target.closest(
      "[data-filter], [data-filter-v3], [data-jump-category]",
    );
    if (categoryButton) {
      send("category_filter", {
        category:
          categoryButton.dataset.filter ||
          categoryButton.dataset.filterV3 ||
          categoryButton.dataset.jumpCategory ||
          "all",
        source_page: window.location.pathname,
      });
    }

    if (event.target.closest("[data-calc]")) {
      send("shipping_calculator_use", {
        source_page: window.location.pathname,
      });
    }

    const languageButton = event.target.closest("[data-lang]");
    if (languageButton) {
      send("language_change", {
        language: languageButton.dataset.lang || "unknown",
      });
    }
  });

  document.addEventListener("submit", (event) => {
    const form = event.target.closest("[data-search-form]");
    if (!form) return;
    const query = form.querySelector("[data-hero-search]")?.value.trim() || "";
    const category = form.querySelector("[data-hero-category]")?.value || "all";
    send("product_search", {
      search_category: category,
      query_length: query.length,
    });
    send("spreadsheet_search", {
      search_category: category,
      query_length: query.length,
      source_page: window.location.pathname,
    });
  });
})();
