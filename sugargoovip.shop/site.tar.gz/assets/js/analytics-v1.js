(() => {
  const send = (name, params = {}) => {
    if (typeof window.gtag === "function") window.gtag("event", name, params);
  };

  const labelFor = (element) =>
    (element.getAttribute("aria-label") || element.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 100);

  document.addEventListener("click", (event) => {
    const link = event.target.closest("a[href]");
    if (link) {
      let target;
      try {
        target = new URL(link.href, window.location.href);
      } catch (_) {
        target = null;
      }

      if (target && /(^|\.)kakobuymake\.com$/i.test(target.hostname)) {
        send("outbound_product_click", {
          link_domain: target.hostname,
          link_path: target.pathname,
          link_text: labelFor(link),
        });
      } else if (
        target &&
        target.origin === window.location.origin &&
        /^\/guides?(?:$|-)/.test(target.pathname)
      ) {
        send("guide_open", {
          link_path: target.pathname,
          link_text: labelFor(link),
        });
      }
    }

    const saveButton = event.target.closest("[data-save]");
    if (saveButton) {
      send("product_save_toggle", { product_id: saveButton.dataset.save || "unknown" });
    }

    const languageButton = event.target.closest("[data-lang]");
    if (languageButton) {
      send("language_change", { language: languageButton.dataset.lang || "unknown" });
    }
  });

  document.addEventListener("submit", (event) => {
    const form = event.target.closest("[data-search-form]");
    if (!form) return;
    const query = form.querySelector("[data-hero-search]")?.value.trim() || "";
    const category = form.querySelector("[data-hero-category]")?.value || "all";
    send("product_search", { search_category: category, query_length: query.length });
  });
})();
